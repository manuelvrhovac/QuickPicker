//
//  Created by Manuel Vrhovac on 20/08/2018.
//  Copyright © 2018 Manuel Vrhovac. All rights reserved.
//

import Foundation


enum NextIndexGeneratorDirection {
    /// Indexes after current are near indexes. Example: 1, 2, 3, 4...
    case upcoming(start: Int)
    // Indexes before current. Example: -1, -2, -3
    case past(start: Int)
    /// Both indexes above and under current are near indexes. Example(rarity:3): 0, 1, 2, -1, 3, 4, 5, -2...
    case upcomingAndPast(start: Int, rarity: Int)
}

protocol NextIndexGeneratorProtocol {
    func currentIndex(for generator: NextIndexGenerator?) -> Int
    func count(for generator: NextIndexGenerator?) -> Int
}

class NextIndexGenerator {
    /*
    /// What is the number of items in the sequence
    private var countGetter: ()->Int
    
    /// A block that will return the current index
    private var delegate?.currentIndex(for: self): () -> Int
    */
    
    var delegate: NextIndexGeneratorProtocol!
    
    /// How many indexes against elementsToSkip before returning nil
    private var range: Int
    
    /// Where to go from currentIndex
    private var direction: NextIndexGeneratorDirection
    
    /// Take from behind when index is negative, and take from beginning when > count
    private var overflowAllowed: Bool
    
    init(/*countGetter: @escaping ()->Int, delegate?.currentIndex(for: self): @escaping ()->Int, */range: Int, direction: NextIndexGeneratorDirection, overflowAllowed: Bool) {
        /*self.countGetter = countGetter
        self.delegate?.currentIndex(for: self) = delegate?.currentIndex(for: self)*/
        self.range = range
        self.direction = direction
        self.overflowAllowed = overflowAllowed
    }
    
    
    var nextIndex: Int? {
        return nextIndex(after: delegate?.currentIndex(for: self))
    }
    
    /// Creates nextIndex after specific index
    func nextIndex(after index: Int?) -> Int? {
        guard let index = index else { return nil }
        return nextIndexes(after: index).first
    }
    
    
    
    var nextIndexes: [Int] {
        return nextIndexes(after: delegate?.currentIndex(for: self))
    }
    
    /// Create X indexes after specific index (X = range)
    func nextIndexes(after index: Int?) -> [Int] {
        guard let index = index else { return [] }
        let count = delegate.count(for: self)
        let increments = createIncrements()
        
        // offset increments with currentIndex
        var nextIndexes = increments.map{ index + $0 }
        
        // if overflow allowed, turn negative indexes into positive counting back
        //(ex. current 2, 3, 1, 4, 5, 0, 6, 7, 99, 8, 9, 98, 10...
        if overflowAllowed {
            nextIndexes = nextIndexes.map{ ($0+count)%count }
        }
        
        // drop indexes outside of range
        nextIndexes = nextIndexes.filter{ 0..<count ~= $0}
        
        return nextIndexes
    }
    
    
    /// Create X increments (X = count)
    private func createIncrements() -> [Int] {
        switch self.direction {
        case .upcoming(let start):
            // start 3, count 10
            // 3, 4, 5, 6, 7, 8, 9, 10, 11, 12
            return Array(start..<(range+start))
            
        case .upcomingAndPast(let start, var rarity):
            // start 3, count 10, rarity 2
            // 3, 4, 2, 5, 6, 1, 7, 8, 0, 9
            var increments = Array(start...(range+start))
            rarity = rarity < 1 ? 1 : rarity
            for index in 1..<range {
                let insertionIndex = index*(rarity+1) - 1
                if insertionIndex >= increments.count { break }
                increments.insert(-index, at: insertionIndex)
            }
            return Array(increments[0..<range])
            
        case .past(let start):
            // start 3, count 10
            // 3, 2, 1, 0, -1, -2, -3, -4, -5, -6
            return Array((start-range+1)...start).reversed()
        }
    }

    
}
