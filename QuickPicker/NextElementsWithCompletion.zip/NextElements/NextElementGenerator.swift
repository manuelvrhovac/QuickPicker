//
//  NearAssetDataSource.swift
//  Wideshow4
//
//  Created by Manuel Vrhovac on 20/08/2018.
//  Copyright © 2018 Manuel Vrhovac. All rights reserved.
//

import Foundation


protocol NextElementGeneratorProtocol {
    
    func elements<T: Hashable>(for generator: NextElementGenerator<T>?) -> [T]
    func elementsToSkip<T: Hashable>(for generator: NextElementGenerator<T>?) -> [T]
}

/**
 Having a list of objects and current index, NextElements is used to return the next element according to its options.
 
 If elementsToSkipGetter is implemented, then NextElements will return next element that is not contained by elementsToSkip. For example, this can be used for getting next PHAsset whose image hasn't been cached yet.

 See NextIndexGenerator for more information.

*/
class NextElementGenerator<T: Hashable>: NSObject {
    
    /*var elementsToSkipGetter: (()->[T])?
    var elementsGetter: (()->[T])*/
    
    var delegate: NextElementGeneratorProtocol!
    private var nextIndexGenerator: NextIndexGenerator
    
    init(/*elementsGetter: @escaping ()->[T], elementsToSkipGetter: @escaping ()->[T], */nextIndexGenerator: NextIndexGenerator) {
        /*self.elementsGetter = elementsGetter
        self.elementsToSkipGetter = elementsToSkipGetter*/
        self.nextIndexGenerator = nextIndexGenerator
    }
    
    var next: T? {
        
        let nextIndexes = nextIndexGenerator.nextIndexes
        let elements = delegate?.elements(for: self) ?? []
        let elementsToSkip = delegate?.elementsToSkip(for: self) ?? []
        
        // find a next index that is not contained in elemntsToSkip
        guard let index = nextIndexes.first(where: {!elementsToSkip.contains(elements[$0])}) else {
            return nil
        }
        
        print("Near asset: \(index)")
        return elements[index]
    }
}





/*
 extension NextIndexDataSource {
 
 
 func next<T: Hashable>(_ type: T.Type, sender: NSObject, alreadyCached: [T]) -> T? {
 
 let currentIndex = self.currentIndex(sender: sender)
 let objects = self.objects(type, sender: sender)
 let options = self.options(sender: sender)
 
 let count = objects.count
 let max = min(options.range ?? count, count)
 
 // current one and next ones (0, 1, 2, 3, 4...)
 var increments = Array(0...max)
 switch options.direction {
 case .upcoming:
 break
 case .past:
 increments = increments.map(-)
 case .upcomingAndPast(var rarity):
 rarity = rarity < 1 ? 1 : rarity
 for index in 1...max {
 let insertionIndex = index*(rarity+1) - 1
 if insertionIndex >= increments.count { break }
 increments.insert(-index, at: insertionIndex)
 }
 }
 
 // offset increments with currentIndex
 var indexes = increments.map{ currentIndex + $0 }
 
 // if overflow allowed, turn negative indexes into positive counting back
 //(ex. current 2, 3, 1, 4, 5, 0, 6, 7, 99, 8, 9, 98, 10...
 if options.overflowAllowed {
 indexes = indexes.map{ ($0+count)%count }
 }
 
 indexes = indexes.filter{ 0..<count ~= $0} // limit
 guard let nearObjectIndex = indexes.first(where: {!alreadyCached.contains(objects[$0])}) else {
 return nil
 }
 print("Near asset: \(nearObjectIndex)")
 return objects[nearObjectIndex]
 }
 
 }*/
